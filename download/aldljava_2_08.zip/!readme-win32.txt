
INSTRUKCJA OBSLUGI SKANERA ALDL-Java (wersja skr�cona)
Autor: Pawe� Marks

Biblioteki:
- Aplikacja wykorzystuje bibliotek� RXTX 2.1.7 (http://rxtx.org) z modyfikacjami pobranymi z ftp://ftp.qbang.org/pub/rxtx/rxtx-2.1-8-testing/
- Do rysowania deski rozdzielczej wykorzystana zosta�a biblioteka JFreeChart 1.0.13 (http://www.jfree.org/jfreechart/)

Instalacja licencji demonstracyjnej:
1. Nale�y uruchomi� plik licenseInstall.bat.
2. Po wy�wietleniu okna dialogowego zaakceptowa� warunki korzystania z programu.


Uruchomienie:
1. Dwuklik z poziomu systemu Windows na pliku ALDL.jar
2. Wpisanie polecenia: java -jar ALDL.jar
Opcjonalnie mo�na poda� �cie�k� do pliku aldl.conf jako parametr (np. java -jar ALDL.jar c:\blabla\aldl.conf), domy�lnie poszuiwany jest on w bie��cym katalogu.

Konfiguracja:
W pliku ALDL.conf aktualnie znajduj� si� cztery pozycje, np:

commPortNo = 3
commSpeed = 8192
loggerEnable = false
loggerDirectory = D:\ALDLLog

Pierwsze dwie linijki okre�laj� numer portu COM (w tym wypadku COM3) oraz pr�dko�� komunikacji.
Odbierane z ECU dane mog� by� zapisywane jezeli ustawimy loggerEnable = true. Zapis b�dzie dokonywany do katalogu okre�lonego przez loggerDirectory. Wskazany katalog MUSI istnie� na dysku.
Je�eli juz w��czyli�my logowanie, to mo�na wpisa� dodatkowy parametr rawLogEnable = true, co spowoduje, �e b�d� tak�e rejestrowane dane w postaci surowej (nie zdekodowanej) tak jak przysz�y z ECU.

Wymagania:
Zainstalowana JAVA 1.5 (wystarczy JRE). Kto nie ma, mo�e pobra� z http://java.sun.com/

