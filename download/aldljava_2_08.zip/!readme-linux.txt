
INSTRUKCJA OBSLUGI SKANERA ALDL-Java (wersja skr�cona)
Autor: Pawe� Marks

Biblioteki:
- Aplikacja wykorzystuje bibliotek� RXTX 2.1.7 (http://rxtx.org) z modyfikacjami pobranymi z ftp://ftp.qbang.org/pub/rxtx/rxtx-2.1-8-testing/
- Do rysowania deski rozdzielczej wykorzystana zosta�a biblioteka JFreeChart 1.0.13 (http://www.jfree.org/jfreechart/)

Instalacja licencji demonstracyjnej:
1. Nale�y zainstalowa� plik z licencj� wydaj�c polecenie (licencja musi by� zainstalowana dla ka�dego u�ytkownika systemowego z osobna)
    java -cp ALDL.jar:lib/CommonTools.jar pl.geowiert.common.licensing.LicenseManager -install aldl_demo.lic
2. Po wy�wietleniu okna dialogowego zaakceptowa� warunki korzystania z programu.


Uruchomienie:
1. Wpisanie polecenia: java -Djava.library.path=. -jar ALDL.jar
Opcjonalnie mo�na poda� �cie�k� do pliku aldl.conf jako parametr, domy�lnie poszuiwany jest on w bie��cym katalogu.

Konfiguracja:
W pliku ALDL.conf  znajduj� si� parametry konfiguracyjne, np:

commPortNo = 0
commSpeed = 8192
loggerEnable = false
loggerDirectory = D:\ALDLLog

Pierwsze dwie linijki okre�laj� numer portu COM (w tym wypadku /dev/ttyUSB0 lub /dev/ttyS0) oraz pr�dko�� komunikacji.
Odbierane z ECU dane mog� by� zapisywane jezeli ustawimy loggerEnable = true. Zapis b�dzie dokonywany do katalogu okre�lonego przez loggerDirectory. Wskazany katalog MUSI istnie� na dysku.
Je�eli juz w��czyli�my logowanie, to mo�na wpisa� dodatkowy parametr rawLogEnable = true, co spowoduje, �e b�d� tak�e rejestrowane dane w postaci surowej (nie zdekodowanej) tak jak przysz�y z ECU.

Wymagania:
Zainstalowana JAVA 1.5 (wystarczy JRE). Kto nie ma, mo�e pobra� z http://java.sun.com/

Biblioteki natywne:
W zale�no�ci od wersji systemu 32-bit lub 64-bit nale�y do katalogu z plikiem ALDL.jar skopiowa� odpowiedni� wersj� biblioteki natywnej librxtxSerial.so.
Je�eli posiadamy system 32-bitowy nale�y wybra� biblotek� z katalogu native-libs/rxtx/linux. Dla systemu 64-bitowego wybieramy folder native-libs/rxtx/linux64.
Mo�na r�wnie� zamiast kopiowania poda� odpowiedni� �cie�k� podczas uruchamiania, np:
java -Djava.library.path=./native-libs/rxtx/linux64 -jar ALDL.jar

UWAGA:
U�ytkownik, z kt�rego uruchamiana jest aplikacja musi znajdowa� si� w grupie "uucp" lub "lock" oraz musi posiada� uprawnienia do odczytu i zapisu do portu szeregowego.

